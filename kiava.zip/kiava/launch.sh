#!/bin/bash
while true; do
   ./tg -s bot.lua
   sleep 2
  done



